import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ShoppingBag, ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { CartItemWithProduct } from "@shared/schema";

export default function Navbar() {
  const [location] = useLocation();
  
  const { data: cartItems = [] } = useQuery<CartItemWithProduct[]>({
    queryKey: ["/api/cart"],
  });

  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  return (
    <nav className="bg-primary-blue text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/">
            <div className="flex items-center cursor-pointer hover:opacity-80 transition-opacity">
              <ShoppingBag className="h-8 w-8 mr-3" />
              <span className="text-xl font-bold">MyShop</span>
            </div>
          </Link>
          
          <div className="flex items-center space-x-6">
            <div className="hidden md:flex space-x-6">
              <Link href="/">
                <span className={`cursor-pointer hover:text-blue-200 transition-colors ${
                  location === "/" ? "text-blue-200" : ""
                }`}>
                  Home
                </span>
              </Link>
              <span className="cursor-pointer hover:text-blue-200 transition-colors">Categories</span>
              <span className="cursor-pointer hover:text-blue-200 transition-colors">About</span>
            </div>
            
            <Link href="/cart">
              <div className="relative cursor-pointer hover:bg-blue-600 px-3 py-2 rounded-lg transition-colors flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                <span className="font-medium">Cart</span>
                {cartItemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-500 text-white text-xs h-6 w-6 flex items-center justify-center p-0 rounded-full">
                    {cartItemCount}
                  </Badge>
                )}
              </div>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
